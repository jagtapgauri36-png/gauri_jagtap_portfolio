GAURI JAGTAP — HTML & CSS PORTFOLIO

Files:
- index.html: website structure and content
- style.css: colors, layout, responsive design and hover effects

HOW TO OPEN:
1. Extract this ZIP into a folder.
2. Open index.html in Chrome or Edge.
3. To edit, open the folder in Visual Studio Code.

BEFORE SUBMISSION:
- Replace gauri.jagtap@example.com with your real email in index.html.
- Check your name, college, year and skills are correct.
- Take one desktop screenshot and one mobile screenshot.
- Test every navigation link.
- This project uses HTML and CSS only. The weather card is a static design demo.
